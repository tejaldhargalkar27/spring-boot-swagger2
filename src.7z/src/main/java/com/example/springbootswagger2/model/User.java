package com.example.springbootswagger2.model;

import io.swagger.annotations.ApiModelProperty;

public class User {


	@ApiModelProperty(notes = "Id of the User",name="id",required=true,value="0")
	private int id;
	@ApiModelProperty(notes = "First Name of the User",name="first_name",required=true,value="test fname")
	private String first_name;
	@ApiModelProperty(notes = "Last Name of the User",name="last_name",required=true,value="test lname")
	private String last_name;
	@ApiModelProperty(notes = "Email of the User",name="email",required=true,value="test email")
	private String email;
	@ApiModelProperty(notes = "ip_address of the User",name="ip_address",required=true,value="test ip_address")
	private String ip_address;
	@ApiModelProperty(notes = "latitude of the User",name="latitude",required=true,value="test latitude")
	private double latitude;
	@ApiModelProperty(notes = "longitude of the User",name="longitude",required=true,value="test longitude")
	private double longitude;
	@ApiModelProperty(notes = "City of the User",name="city",required=true,value="test city")
	private String city;

	public User(int id, String first_name, String last_name, String email, String ip_address, double latitude,
			double longitude, String city) {
		super();
		this.id = id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email = email;
		this.ip_address = ip_address;
		this.latitude = latitude;
		this.longitude = longitude;
		this.city = city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	public int getId() {
		return id;
	}


	public String getFirst_name() {
		return first_name;
	}


	public String getLast_name() {
		return last_name;
	}


	public String getEmail() {
		return email;
	}


	public String getIp_address() {
		return ip_address;
	}


	public double getLatitude() {
		return latitude;
	}


	public double getLongitude() {
		return longitude;
	}


	public String getCity() {
		return city;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", first_name=" + first_name + ", last_name=" + last_name + ", email=" + email
				+ ", ip_address=" + ip_address + ", latitude=" + latitude + ", longitude=" + longitude + ", city="
				+ city + "]";
	}
}

