package com.example.springbootswagger2.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springbootswagger2.model.User;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "Swagger2DemoRestController", description = "REST Apis related to User Entity!!!!")
@RestController
public class Swagger2DemoRestController {
	
	List<User> listOfUsers = new ArrayList<User>();
	
	/*Base URL - http://localhost:8080/swagger2-demo/swagger-ui.html#/
	 * Instructions URL - http://localhost:8080/swagger2-demo/swagger-ui.html#/instructions
	 * GetUsersNearLondon URL - http://localhost:8080/swagger2-demo/swagger-ui.html#/getUsersNearLondon*/
	
	
	@ApiOperation(value = "Instructions", response = String.class, tags = "instructions")
	@RequestMapping(value = "/instructions")
	public String instructions() throws IOException{
		String str = "";
		StringBuffer response = new StringBuffer();
		try {
			URL url = new URL("https://bpdts-test-app.herokuapp.com/instructions");
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
			while (null != (str = br.readLine())) {
				response.append(str);
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.append("\r\n Solution: Access 'http://localhost:8080/swagger2-demo/swagger-ui.html#/getUsersNearLondon' url to view the response.");
		return response.toString();
	}

	@ApiOperation(value = "Get specific Users in vicinity of London ", response = User.class, tags = "getUsersNearLondon")
	@RequestMapping(value = "/getUsersNearLondon")
	public List<User> getUsersNearLondon() throws IOException {
		String str = "";
		StringBuffer response = new StringBuffer();
		List<User> listOfUsersNearLondon = new ArrayList<User>();
		try {
			URL url = new URL("https://bpdts-test-app.herokuapp.com/city/London/users");
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));

			while (null != (str = br.readLine())) {
				response.append(str);
			}

			String json = response.toString(); // Your response; for simplicity I stringified it.
			Gson gson = new GsonBuilder().create();
			Type showType = new TypeToken<Collection<User>>() {
			}.getType();
			ArrayList<User> responses = gson.fromJson(json, showType);

			for (User user : responses) {
				user.setCity("London");
				listOfUsersNearLondon.add(user);
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Iterator<User> iterator = getUsers().iterator(); iterator.hasNext(); ) {
			User user = iterator.next();
			
			/*Assuming that the extreme latitude and longitude coordinates specified 
			 * for London in the above api shared, are boundaries of London.
			 * 
			 * 50 miles = 0.72286 degree longitude
			 * 50 miles = 0.72769 degree latitude
			 * 
			 * Farthest longitudes -> 113.6680747 and -84.08
			 * Farthest latitudes -> 37.13 and -8.1844859
			 * */

			double farthestPositiveLatOfLondon = 37.13 + 0.72769;
			double farthestPositiveLonOfLondon = 113.6680747 + 0.72286;

			double farthestNegativeLatOfLondon = -8.1844859 - 0.72769;
			double farthestNegativeLonOfLondon = -84.08 - 0.72286;
			 

			if ((user.getLatitude() <= farthestPositiveLatOfLondon && user.getLatitude() >= 37.13) || (user.getLongitude() <= farthestPositiveLonOfLondon && user.getLongitude() >= 113.6680747)
				|| (user.getLatitude() >= farthestNegativeLatOfLondon && user.getLatitude() <= -8.1844859) || (user.getLongitude() >= farthestNegativeLonOfLondon && user.getLongitude() <= -84.08)) {
				if(!containsName(listOfUsersNearLondon,user.getFirst_name())) {
					user.setCity("Near London");
					listOfUsersNearLondon.add(user);
				}
			}
		}
		return listOfUsersNearLondon;
	}

	public List<User> getUsers() {
		String str = "";
		StringBuffer response = new StringBuffer();
		try {
			URL url = new URL("https://bpdts-test-app.herokuapp.com/users");
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));

			while (null != (str = br.readLine())) {
				response.append(str);
			}

			String json = response.toString(); // Your response; for simplicity I stringified it.
			Gson gson = new GsonBuilder().create();
			Type showType = new TypeToken<Collection<User>>() {
			}.getType();
			ArrayList<User> responses = gson.fromJson(json, showType);

			for (User user : responses) {
				listOfUsers.add(user);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return listOfUsers;
	}
	
	
	public boolean containsName(final List<User> list, final String name){
	    return list.stream().filter(o -> o.getFirst_name().equals(name)).findFirst().isPresent();
	}

}
